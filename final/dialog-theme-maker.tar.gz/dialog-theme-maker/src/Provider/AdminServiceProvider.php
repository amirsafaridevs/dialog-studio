<?php

declare(strict_types=1);

namespace DialogThemeMaker\Provider;

use DialogThemeMaker\Contract\Abstract\AbstractServiceProvider;
use DialogThemeMaker\Service\Admin\ChatAdminMenu;

/**
 * Admin service provider — wp-admin menus and related hooks.
 */
class AdminServiceProvider extends AbstractServiceProvider
{
    protected function registerServices(): void
    {
        $this->container->singleton( 'admin.chat_menu', ChatAdminMenu::class );
    }

    protected function bootServices(): void
    {
        $this->container->get( 'admin.chat_menu' )->boot();
    }
}
