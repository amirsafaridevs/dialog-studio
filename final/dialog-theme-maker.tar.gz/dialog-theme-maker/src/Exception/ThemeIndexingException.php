<?php

declare(strict_types=1);

namespace DialogThemeMaker\Exception;

/**
 * Thrown when the active theme cannot be resolved or scanned.
 */
class ThemeIndexingException extends \RuntimeException
{
}
