<?php

/**
 * Plugin Name: Dialog Theme Maker
 * Description: DialogThemeMaker is a plugin for creating and customizing themes for WordPress.
 * Version: 1.0.0
 * Author: Amir Safari
 * Author URI: https://artacode.net
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: DialogThemeMaker
 * Domain Path: /languages
 */


if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'DialogThemeMaker_PLUGIN_FILE' ) ) {
	define( 'DialogThemeMaker_PLUGIN_FILE', __FILE__ );
}

require_once __DIR__ . '/vendor/autoload.php';

\DialogThemeMaker\App\App::get();

register_activation_hook(
	DialogThemeMaker_PLUGIN_FILE,
	static function () {
		\DialogThemeMaker\Core\Application::get()->pluginActivation();
	}
);
